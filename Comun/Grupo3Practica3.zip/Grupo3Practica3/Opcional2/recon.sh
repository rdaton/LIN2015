make clean
make
sudo rmmod fifomod
sudo insmod fifomod.ko
