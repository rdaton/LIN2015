#!/bin/bash
mknod /dev/fifomod c 222 0
